export interface AudioSettings {
  sound: boolean;
  music: boolean;
  narration: boolean;
  voiceRate: number;
}

type Effect = "click" | "correct" | "wrong" | "tick" | "coin" | "victory" | "defeat" | "whoosh";

class AudioEngine {
  private ctx: AudioContext | null = null;
  private musicTimer: number | null = null;
  private musicStep = 0;
  private unlocked = false;
  private voice: SpeechSynthesisVoice | null = null;
  private voiceListener = false;
  private settings: AudioSettings = { sound: true, music: true, narration: true, voiceRate: 0.92 };

  setSettings(next: AudioSettings) {
    this.settings = next;
    if (!next.sound || !next.music || !next.narration) {
      if (!next.narration) this.stopSpeech();
      if (!next.sound || !next.music) this.stopMusic();
    }
    if (this.unlocked && next.sound && next.music && this.musicTimer === null) this.startMusic();
    if (!next.sound) this.stopSpeech();
  }

  unlock() {
    this.refreshVoices();
    if (this.unlocked) {
      void this.ctx?.resume();
      return;
    }
    const Ctor: typeof AudioContext | undefined =
      window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    try {
      this.ctx = new Ctor();
      this.unlocked = true;
      void this.ctx.resume();
      if (this.settings.sound && this.settings.music) this.startMusic();
    } catch {
      this.ctx = null;
    }
  }

  private note(freq: number, duration: number, type: OscillatorType, gain: number, offset = 0) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime + offset;
    const osc = this.ctx.createOscillator();
    const amp = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    amp.gain.setValueAtTime(0.0001, now);
    amp.gain.linearRampToValueAtTime(Math.max(0.0002, gain), now + 0.012);
    amp.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(amp);
    amp.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  private startMusic() {
    if (!this.ctx || !this.unlocked || this.musicTimer !== null) return;
    const scale = [293.66, 329.63, 392, 440, 523.25, 587.33, 523.25, 440, 392, 329.63];
    const pattern = [0, 2, 4, 2, 5, 4, 2, 1, 0, 3, 4, 3, 2, 1, 0, 2];
    const playStep = () => {
      if (!this.settings.sound || !this.settings.music || !this.ctx) return;
      const i = this.musicStep++ % pattern.length;
      this.note(scale[pattern[i]], 0.24, "sine", 0.018);
      if (i % 4 === 0) this.note(scale[pattern[i]] / 2, 0.42, "triangle", 0.012);
    };
    playStep();
    this.musicTimer = window.setInterval(playStep, 285);
  }

  private stopMusic() {
    if (this.musicTimer !== null) window.clearInterval(this.musicTimer);
    this.musicTimer = null;
  }

  play(effect: Effect) {
    if (!this.settings.sound || !this.ctx || !this.unlocked) return;
    switch (effect) {
      case "click":
        this.note(660, 0.05, "triangle", 0.035);
        break;
      case "tick":
        this.note(880, 0.055, "square", 0.025);
        break;
      case "correct":
        [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => this.note(f, 0.18, "sine", 0.06, i * 0.065));
        break;
      case "wrong":
        this.note(230, 0.16, "sawtooth", 0.045);
        this.note(174, 0.22, "sawtooth", 0.04, 0.11);
        break;
      case "coin":
        this.note(1046.5, 0.09, "sine", 0.05);
        this.note(1568, 0.14, "sine", 0.04, 0.07);
        break;
      case "victory":
        [392, 523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) =>
          this.note(f, 0.32, "triangle", 0.055, i * 0.115)
        );
        break;
      case "defeat":
        [392, 349.23, 293.66, 220].forEach((f, i) => this.note(f, 0.34, "triangle", 0.05, i * 0.16));
        break;
      case "whoosh":
        this.note(320, 0.13, "triangle", 0.028);
        this.note(480, 0.12, "triangle", 0.022, 0.07);
        break;
    }
  }

  private refreshVoices() {
    if (!("speechSynthesis" in window)) return;
    const find = () =>
      window.speechSynthesis.getVoices().find((v) => v.lang.toLowerCase().replace("_", "-").startsWith("fa")) ||
      window.speechSynthesis.getVoices().find((v) => /persian|farsi/i.test(v.name)) ||
      null;
    this.voice = this.voice || find();
    if (!this.voiceListener) {
      this.voiceListener = true;
      window.speechSynthesis.addEventListener("voiceschanged", () => { this.voice = find(); }, { once: true });
    }
  }

  private pickVoice(): SpeechSynthesisVoice | null {
    if (!("speechSynthesis" in window)) return null;
    if (this.voice) return this.voice;
    const voices = window.speechSynthesis.getVoices();
    return (
      voices.find((v) => v.lang.toLowerCase().replace("_", "-").startsWith("fa")) ||
      voices.find((v) => /persian|farsi/i.test(v.name)) ||
      null
    );
  }

  speak(text: string, manual = false) {
    if (!this.settings.sound || (!this.settings.narration && !manual)) return;
    if (!("speechSynthesis" in window) || !text) return;
    try {
      this.refreshVoices();
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text.replace(/[«»؟]/g, " ").replace(/\s+/g, " ").trim());
      const voice = this.pickVoice();
      if (voice) utterance.voice = voice;
      utterance.lang = "fa-IR";
      utterance.rate = this.settings.voiceRate;
      utterance.pitch = 1.05;
      utterance.volume = 0.92;
      window.speechSynthesis.speak(utterance);
    } catch {
      /* برخی مرورگرها صدای فارسی ندارند؛ بازی بدون گفتار ادامه مییابد. */
    }
  }

  speakQuestion(text: string, manual = false) {
    this.speak(text, manual);
  }

  speakOptions(options: string[], labels: string[]) {
    const text = options.map((o, i) => `${labels[i]}: ${o}`).join(". ");
    this.speak(`گزینهها. ${text}`, true);
  }

  stopSpeech() {
    if ("speechSynthesis" in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        /* ignored */
      }
    }
  }
}

export const audio = new AudioEngine();
