import {
  getDailySeed,
  pickQuestions,
  seedFromString,
  seededRandom,
  TOTAL_QUESTIONS,
  type Difficulty,
  type Question,
} from "../data/questions";

export type Mode = "competition" | "practice" | "boss" | "duo" | "daily";
export type Screen = "home" | "quiz" | "achievements" | "shop" | "settings" | "leaderboard" | "about";

export interface Settings {
  sound: boolean;
  music: boolean;
  narration: boolean;
  voiceRate: number;
  reduceMotion: boolean;
}

export interface ScoreEntry {
  id: string;
  mode: Mode;
  name: string;
  score: number;
  correct: number;
  total: number;
  date: string;
}

export interface Progress {
  name: string;
  coins: number;
  totalCoins: number;
  xp: number;
  totalAnswers: number;
  totalCorrect: number;
  bestStreak: number;
  games: number;
  bossWins: number;
  duoWins: number;
  perfectRounds: number;
  dailyCount: number;
  dailyDate: string;
  achievements: string[];
  unlockedChars: string[];
  unlockedThemes: string[];
  char: string;
  theme: string;
  modesPlayed: Mode[];
  scores: ScoreEntry[];
  seenIds: number[];
  settings: Settings;
}

export const MODE_INFO: Record<Mode, { title: string; short: string; icon: string; description: string; length: number; timer: number; color: string }> = {
  competition: { title: "رقابت اصلی", short: "رقابت", icon: "🏆", description: "۲۰ پرسش، ۱۵ ثانیه و امتیاز سرعت", length: 20, timer: 15, color: "rgba(255,209,102,.22)" },
  practice: { title: "تمرین آزاد", short: "تمرین", icon: "📖", description: "پرسشهای نامحدود با توضیح کامل", length: Infinity, timer: 0, color: "rgba(53,214,193,.22)" },
  boss: { title: "چالش استاد", short: "غول آخر", icon: "🐉", description: "۱۲ پرسش دشوار و تنها ۳ جان", length: 12, timer: 18, color: "rgba(255,109,158,.22)" },
  duo: { title: "دو نفره", short: "دو نفره", icon: "⚔️", description: "نوبتی روی یک گوشی، ۸ پرسش برای هر بازیکن", length: 16, timer: 15, color: "rgba(157,123,255,.22)" },
  daily: { title: "چالش روزانه", short: "روزانه", icon: "🌟", description: "۱۰ پرسش ویژهٔ امروز و پاداش تازه", length: 10, timer: 15, color: "rgba(255,183,94,.22)" },
};

export const LEVELS = [
  { title: "تازهکار", xp: 0, icon: "🌱" },
  { title: "دانشآموز", xp: 80, icon: "✏️" },
  { title: "کتابخوان", xp: 200, icon: "📚" },
  { title: "استاد دستور", xp: 380, icon: "🧩" },
  { title: "شعرشناس", xp: 600, icon: "🪶" },
  { title: "نابغهٔ ادب", xp: 880, icon: "💡" },
  { title: "قهرمان فارسی", xp: 1220, icon: "🏅" },
  { title: "قلم زرین", xp: 1650, icon: "🖋️" },
  { title: "استاد فارسی", xp: 2200, icon: "👑" },
  { title: "اسطورهٔ ادبیات", xp: 2900, icon: "🌌" },
];

export const CHARACTERS = [
  { id: "kavoshgar", name: "کاوشگر دانش", icon: "🧭", cost: 0 },
  { id: "ketab", name: "شاگرد کتاب", icon: "📚", cost: 90 },
  { id: "shir", name: "شیر ایرانی", icon: "🦁", cost: 180 },
  { id: "setare", name: "ستارهٔ ادب", icon: "✨", cost: 300 },
  { id: "tavoos", name: "طاووس مینیاتور", icon: "🦚", cost: 450 },
  { id: "simorgh", name: "سیمرغ خرد", icon: "🕊️", cost: 700 },
];

export const THEMES = [
  { id: "yalda", name: "شب یلدا", icon: "🌙", cost: 0, className: "" },
  { id: "firoozeh", name: "فیروزهٔ اصفهان", icon: "🟦", cost: 110, className: "theme-firoozeh" },
  { id: "golestan", name: "گلستان", icon: "🌿", cost: 190, className: "theme-golestan" },
  { id: "kavir", name: "کویر ستاره", icon: "🌠", cost: 280, className: "theme-kavir" },
  { id: "shiraz", name: "شیراز رنگی", icon: "🌷", cost: 390, className: "theme-shiraz" },
];

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  condition: (p: Progress) => boolean;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: "first", title: "نخستین گام", description: "به نخستین پرسش پاسخ بده", icon: "👣", condition: (p) => p.totalAnswers >= 1 },
  { id: "correct10", title: "ده پاسخ درست", description: "۱۰ پاسخ درست ثبت کن", icon: "✅", condition: (p) => p.totalCorrect >= 10 },
  { id: "correct50", title: "پنجاه پاسخ درست", description: "۵۰ پاسخ درست ثبت کن", icon: "🎯", condition: (p) => p.totalCorrect >= 50 },
  { id: "streak5", title: "پیاپی پنج", description: "۵ پاسخ درست پشت سر هم", icon: "🔥", condition: (p) => p.bestStreak >= 5 },
  { id: "streak10", title: "آتشینقلم", description: "۱۰ پاسخ درست پشت سر هم", icon: "⚡", condition: (p) => p.bestStreak >= 10 },
  { id: "coins", title: "گنج کوچک", description: "مجموعاً ۲۵۰ سکه به دست آور", icon: "💰", condition: (p) => p.totalCoins >= 250 },
  { id: "allModes", title: "همهٔ میدانها", description: "همهٔ حالتهای بازی را تجربه کن", icon: "🗺️", condition: (p) => p.modesPlayed.length >= 5 },
  { id: "daily", title: "پیگیر امروز", description: "یک چالش روزانه را کامل کن", icon: "📅", condition: (p) => p.dailyCount >= 1 },
  { id: "perfect", title: "بینقص", description: "یک دور را بدون خطا به پایان ببر", icon: "💎", condition: (p) => p.perfectRounds >= 1 },
  { id: "boss", title: "فاتح استاد", description: "چالش استاد را پیروز شو", icon: "🐉", condition: (p) => p.bossWins >= 1 },
  { id: "duel", title: "رقیبجو", description: "یک رقابت دونفره کامل کن", icon: "⚔️", condition: (p) => p.duoWins >= 1 },
  { id: "level5", title: "نابغهٔ ادب", description: "به سطح پنجم برس", icon: "🏆", condition: (p) => levelForXp(p.xp).index >= 4 },
];

const STORAGE_KEY = "persian-quest-grade7-v1";

export function defaultProgress(): Progress {
  return {
    name: "جهانگرد فارسی",
    coins: 60,
    totalCoins: 60,
    xp: 0,
    totalAnswers: 0,
    totalCorrect: 0,
    bestStreak: 0,
    games: 0,
    bossWins: 0,
    duoWins: 0,
    perfectRounds: 0,
    dailyCount: 0,
    dailyDate: "",
    achievements: [],
    unlockedChars: ["kavoshgar"],
    unlockedThemes: ["yalda"],
    char: "kavoshgar",
    theme: "yalda",
    modesPlayed: [],
    scores: [],
    seenIds: [],
    settings: { sound: true, music: true, narration: true, voiceRate: 0.92, reduceMotion: false },
  };
}

export function loadProgress(): Progress {
  const base = defaultProgress();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return base;
    const saved = JSON.parse(raw) as Partial<Progress>;
    return {
      ...base,
      ...saved,
      settings: { ...base.settings, ...(saved.settings ?? {}) },
      achievements: Array.isArray(saved.achievements) ? saved.achievements : [],
      unlockedChars: Array.isArray(saved.unlockedChars) && saved.unlockedChars.length ? saved.unlockedChars : base.unlockedChars,
      unlockedThemes: Array.isArray(saved.unlockedThemes) && saved.unlockedThemes.length ? saved.unlockedThemes : base.unlockedThemes,
      modesPlayed: Array.isArray(saved.modesPlayed) ? saved.modesPlayed : [],
      scores: Array.isArray(saved.scores) ? saved.scores : [],
      seenIds: Array.isArray(saved.seenIds) ? saved.seenIds : [],
    };
  } catch {
    return base;
  }
}

export function saveProgress(progress: Progress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    /* حافظه در دسترس نیست؛ بازی همچنان ادامه مییابد. */
  }
}

export function levelForXp(xp: number): { index: number; level: number; progress: number; toNext: number } {
  let index = 0;
  for (let i = 0; i < LEVELS.length; i++) if (xp >= LEVELS[i].xp) index = i;
  const current = LEVELS[index].xp;
  const next = index < LEVELS.length - 1 ? LEVELS[index + 1].xp : current + 900;
  const progress = Math.min(100, Math.max(0, ((xp - current) / (next - current)) * 100));
  return { index, level: index + 1, progress, toNext: Math.max(0, next - xp) };
}

export function fa(value: number | string): string {
  return String(value).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
}

export function faDate(date: Date): string {
  return `${fa(date.getDate())}/${fa(date.getMonth() + 1)}/${fa(date.getFullYear())}`;
}

export function buildDeck(mode: Mode, seen: number[]): Question[] {
  const rng = mode === "daily" ? seededRandom(seedFromString(getDailySeed())) : Math.random;
  const excluded = new Set(seen.slice(-900));
  const deck: Question[] = [];
  const take = (count: number, difficulties: Difficulty[] | null) => {
    const chosen = pickQuestions(count, difficulties, excluded, rng);
    chosen.forEach((q) => excluded.add(q.id));
    deck.push(...chosen);
  };
  if (mode === "competition") {
    take(7, [1]);
    take(7, [2]);
    take(6, [3]);
  } else if (mode === "boss") {
    take(12, [3]);
  } else if (mode === "daily") {
    take(4, [1]);
    take(3, [2]);
    take(3, [3]);
  } else if (mode === "duo") {
    take(6, [1, 2]);
    take(10, [2, 3]);
  } else {
    take(80, null);
  }
  return deck;
}

export function extendDeck(existing: Question[], seen: number[]): Question[] {
  const excluded = new Set([...seen.slice(-900), ...existing.map((q) => q.id)]);
  return pickQuestions(60, null, excluded, Math.random);
}

export function questionCount(): number {
  return TOTAL_QUESTIONS;
}
