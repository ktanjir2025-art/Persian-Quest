import { useEffect, useRef, useState, type CSSProperties } from "react";
import { Confetti, HeroScene, Mascot, Particles, Stars } from "./components/Visuals";
import { getDailySeed, type Question } from "./data/questions";
import { audio } from "./lib/audio";
import {
  ACHIEVEMENTS,
  CHARACTERS,
  LEVELS,
  MODE_INFO,
  THEMES,
  buildDeck,
  extendDeck,
  fa,
  faDate,
  levelForXp,
  loadProgress,
  questionCount,
  saveProgress,
  type Mode,
  type Progress,
  type ScoreEntry,
  type Screen,
} from "./lib/game";

type Phase = "answering" | "feedback";
type Player = 0 | 1;

interface Game {
  mode: Mode;
  deck: Question[];
  index: number;
  phase: Phase;
  selected: number | null;
  correct: boolean | null;
  timedOut: boolean;
  score: number;
  coins: number;
  xpGain: number;
  correctCount: number;
  streak: number;
  bestStreak: number;
  lives: number;
  player: Player;
  scores: [number, number];
  answers: [number, number];
  paused: boolean;
  deadline: number | null;
  remaining: number;
  lastGain: number;
  dailyReward: boolean;
  log: boolean[];
}

interface Result {
  mode: Mode;
  score: number;
  correct: number;
  total: number;
  coins: number;
  xp: number;
  win: boolean;
  quit: boolean;
  title: string;
  subtitle: string;
  isBest: boolean;
  perfect: boolean;
  starCount: number;
  duoScores?: [number, number];
  newLevel?: number;
  specialReward?: string;
  topScores: ScoreEntry[];
}

interface InstallEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
}

const OPTION_KEYS = ["۱", "۲", "۳", "۴"];
const OPTION_WORDS = ["گزینهٔ یک", "گزینهٔ دو", "گزینهٔ سه", "گزینهٔ چهار"];
const DIFFICULTY_LABELS = ["", "آسان", "متوسط", "دشوار"];

function SubHeader({ title, subtitle, onBack }: { title: string; subtitle?: string; onBack: () => void }) {
  return (
    <div className="mb-4 flex items-center gap-3">
      <button className="btn btn-ghost btn-icon" onClick={onBack} aria-label="بازگشت">➜</button>
      <div className="flex-1">
        <h2 className="text-xl font-black text-[var(--gold)]">{title}</h2>
        {subtitle && <p className="text-xs text-[var(--muted)]">{subtitle}</p>}
      </div>
    </div>
  );
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: () => void; label: string }) {
  return (
    <button className={`toggle ${on ? "on" : ""}`} onClick={onChange} role="switch" aria-checked={on} aria-label={label} />
  );
}

export default function App() {
  const [progress, setProgress] = useState<Progress>(() => loadProgress());
  const [screen, setScreen] = useState<Screen>("home");
  const [game, setGame] = useState<Game | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [timeLeft, setTimeLeft] = useState(15);
  const [toast, setToast] = useState<string | null>(null);
  const [shake, setShake] = useState(false);
  const [burstSeed, setBurstSeed] = useState(0);
  const [leaderboardFilter, setLeaderboardFilter] = useState<Mode | "all">("all");
  const [installPrompt, setInstallPrompt] = useState<InstallEvent | null>(null);
  const [installHelp, setInstallHelp] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const progressRef = useRef(progress);
  const gameRef = useRef(game);
  const resultRef = useRef(result);
  const screenRef = useRef(screen);
  const lockRef = useRef(false);
  const toastTimer = useRef<number | null>(null);
  const shakeTimer = useRef<number | null>(null);
  const narrationTimer = useRef<number | null>(null);
  const actionsRef = useRef<{
    answer: (i: number) => void;
    advance: () => void;
    start: (mode: Mode) => void;
    restart: () => void;
    home: () => void;
    pause: () => void;
    toggleSound: () => void;
  }>({
    answer: () => {}, advance: () => {}, start: () => {}, restart: () => {}, home: () => {}, pause: () => {}, toggleSound: () => {},
  });

  progressRef.current = progress;
  gameRef.current = game;
  resultRef.current = result;
  screenRef.current = screen;

  function showToast(message: string) {
    setToast(message);
    if (toastTimer.current !== null) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2800);
  }

  function clearNarration() {
    if (narrationTimer.current !== null) window.clearTimeout(narrationTimer.current);
    narrationTimer.current = null;
    audio.stopSpeech();
  }

  function speakQuestion(q: Question) {
    clearNarration();
    narrationTimer.current = window.setTimeout(() => audio.speakQuestion(q.text), 260);
  }

  function toggleSound() {
    audio.unlock();
    setProgress((p) => ({ ...p, settings: { ...p.settings, sound: !p.settings.sound } }));
  }

  function setSetting<K extends keyof Progress["settings"]>(key: K, value: Progress["settings"][K]) {
    setProgress((p) => ({ ...p, settings: { ...p.settings, [key]: value } }));
  }

  function goHome() {
    clearNarration();
    lockRef.current = false;
    screenRef.current = "home";
    setScreen("home");
    setGame(null);
    setResult(null);
    setShake(false);
    setBurstSeed(0);
    audio.play("click");
  }

  function startGame(mode: Mode) {
    audio.unlock();
    clearNarration();
    const info = MODE_INFO[mode];
    const dailyReward = mode !== "daily" || progressRef.current.dailyDate !== getDailySeed();
    const deck = buildDeck(mode, progressRef.current.seenIds);
    const timer = info.timer;
    const next: Game = {
      mode,
      deck,
      index: 0,
      phase: "answering",
      selected: null,
      correct: null,
      timedOut: false,
      score: 0,
      coins: 0,
      xpGain: 0,
      correctCount: 0,
      streak: 0,
      bestStreak: 0,
      lives: mode === "boss" ? 3 : 0,
      player: 0,
      scores: [0, 0],
      answers: [0, 0],
      paused: false,
      deadline: timer > 0 ? Date.now() + timer * 1000 : null,
      remaining: timer,
      lastGain: 0,
      dailyReward,
      log: [],
    };
    lockRef.current = false;
    screenRef.current = "quiz";
    setScreen("quiz");
    setResult(null);
    setGame(next);
    setTimeLeft(timer);
    setShake(false);
    setBurstSeed(0);
    audio.play("whoosh");
    if (deck[0]) speakQuestion(deck[0]);
    setProgress((p) => ({
      ...p,
      modesPlayed: p.modesPlayed.includes(mode) ? p.modesPlayed : [...p.modesPlayed, mode],
    }));
    if (mode === "daily" && !dailyReward) showToast("چالش امروز انجام شده؛ اینبار بدون پاداش تکرار میشود.");
  }

  function answerQuestion(index: number) {
    const current = gameRef.current;
    if (!current || resultRef.current || screenRef.current !== "quiz" || current.paused || current.phase !== "answering" || lockRef.current) return;
    lockRef.current = true;
    clearNarration();
    const q = current.deck[current.index];
    if (!q) return;
    const timer = MODE_INFO[current.mode].timer;
    const secondsLeft = current.deadline ? Math.max(0, (current.deadline - Date.now()) / 1000) : 0;
    const isCorrect = index >= 0 && index === q.answer;
    const timedOut = index < 0;
    const streak = isCorrect ? current.streak + 1 : 0;
    const fastBonus = isCorrect && timer > 0 ? Math.round(secondsLeft * 4) : 0;
    const comboBonus = isCorrect ? Math.min(120, current.streak * 12) : 0;
    const points = isCorrect ? 100 + q.difficulty * 25 + fastBonus + comboBonus : 0;
    const coins = isCorrect ? 2 + q.difficulty + Math.floor(secondsLeft / 6) : 0;
    const xp = isCorrect ? 8 + q.difficulty * 4 : 1;
    const scores: [number, number] = [...current.scores] as [number, number];
    const answers: [number, number] = [...current.answers] as [number, number];
    if (current.mode === "duo") {
      scores[current.player] += points;
      answers[current.player] += 1;
    }
    const lives = current.mode === "boss" && !isCorrect ? Math.max(0, current.lives - 1) : current.lives;
    const next: Game = {
      ...current,
      phase: "feedback",
      selected: index >= 0 ? index : null,
      correct: isCorrect,
      timedOut,
      score: current.score + points,
      coins: current.coins + coins,
      xpGain: current.xpGain + xp,
      correctCount: current.correctCount + (isCorrect ? 1 : 0),
      streak,
      bestStreak: Math.max(current.bestStreak, streak),
      lives,
      scores,
      answers,
      deadline: null,
      remaining: secondsLeft,
      lastGain: points,
      log: [...current.log, isCorrect],
    };
    setGame(next);
    setTimeLeft(secondsLeft);
    setBurstSeed(isCorrect ? current.index + Math.round(points / 7) + 1 : 0);
    if (!isCorrect) {
      setShake(true);
      if (shakeTimer.current !== null) window.clearTimeout(shakeTimer.current);
      shakeTimer.current = window.setTimeout(() => setShake(false), 460);
      audio.play("wrong");
    } else {
      setShake(false);
      audio.play("correct");
      window.setTimeout(() => audio.play("coin"), 210);
      if (streak >= 3 && streak % 3 === 0) showToast(`🔥 ترکیب ${fa(streak)}تایی! امتیاز اضافه گرفتی`);
    }
    setProgress((p) => ({
      ...p,
      coins: p.coins + coins,
      totalCoins: p.totalCoins + coins,
      xp: p.xp + xp,
      totalAnswers: p.totalAnswers + 1,
      totalCorrect: p.totalCorrect + (isCorrect ? 1 : 0),
      bestStreak: Math.max(p.bestStreak, streak),
      seenIds: [...p.seenIds, q.id].slice(-1400),
    }));
  }

  function finishGame(current: Game, quit = false) {
    clearNarration();
    lockRef.current = true;
    const info = MODE_INFO[current.mode];
    const answered = current.log.length;
    const planned = info.length;
    const completed = !quit && Number.isFinite(planned) && answered >= planned;
    const accuracy = answered ? current.correctCount / answered : 0;
    const duoWinner: Player = current.scores[0] === current.scores[1] ? 0 : current.scores[0] > current.scores[1] ? 0 : 1;
    let win = false;
    if (current.mode === "boss") win = completed && current.lives > 0;
    else if (current.mode === "duo") win = completed && current.scores[0] !== current.scores[1];
    else if (current.mode === "competition") win = completed && current.correctCount >= 12;
    else if (current.mode === "daily") win = completed && current.correctCount >= 6;
    else win = current.correctCount > 0;

    let bonusCoins = 8 + current.correctCount * 2;
    let bonusXp = 20 + current.correctCount * 4;
    if (win) { bonusCoins += 25; bonusXp += 20; }
    if (current.mode === "boss" && win) bonusCoins += 100;
    if (current.mode === "daily" && current.dailyReward && completed) bonusCoins += 50;
    const perfect = completed && answered > 0 && current.correctCount === answered;
    const starCount = accuracy >= 0.85 ? 3 : accuracy >= 0.6 ? 2 : 1;
    const previousScores = progressRef.current.scores;
    const previousBest = previousScores.filter((s) => s.mode === current.mode).reduce((m, s) => Math.max(m, s.score), 0);
    const isBest = current.score > previousBest && current.score > 0;
    const entry: ScoreEntry | null = current.score > 0 ? {
      id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      mode: current.mode,
      name: progressRef.current.name,
      score: current.score,
      correct: current.correctCount,
      total: answered,
      date: faDate(new Date()),
    } : null;
    const topScores = [...(entry ? [entry] : []), ...previousScores].sort((a, b) => b.score - a.score).slice(0, 10);
    const beforeLevel = levelForXp(progressRef.current.xp).level;
    const afterLevel = levelForXp(progressRef.current.xp + bonusXp).level;
    const specialReward = current.mode === "boss" && win ? "شخصیت «شیر ایرانی» آزاد شد" : undefined;

    setProgress((p) => {
      const updated: Progress = {
        ...p,
        coins: p.coins + bonusCoins,
        totalCoins: p.totalCoins + bonusCoins,
        xp: p.xp + bonusXp,
        games: p.games + 1,
        bossWins: p.bossWins + (current.mode === "boss" && win ? 1 : 0),
        duoWins: p.duoWins + (current.mode === "duo" && completed ? 1 : 0),
        perfectRounds: p.perfectRounds + (perfect ? 1 : 0),
        dailyCount: p.dailyCount + (current.mode === "daily" && completed ? 1 : 0),
        dailyDate: current.mode === "daily" && current.dailyReward && completed ? getDailySeed() : p.dailyDate,
        scores: [...(entry ? [entry] : []), ...p.scores].sort((a, b) => b.score - a.score).slice(0, 30),
        modesPlayed: p.modesPlayed.includes(current.mode) ? p.modesPlayed : [...p.modesPlayed, current.mode],
        unlockedChars: specialReward && !p.unlockedChars.includes("shir") ? [...p.unlockedChars, "shir"] : p.unlockedChars,
      };
      return updated;
    });

    let title = "پایان ماجراجویی";
    let subtitle = "تلاشت ثبت شد؛ دوباره امتحان کن!";
    if (quit) { title = "پایان تمرین"; subtitle = "پیشرفت و امتیازت ذخیره شد."; }
    else if (current.mode === "duo" && completed) { title = current.scores[0] === current.scores[1] ? "مساوی!" : `برنده: بازیکن ${duoWinner === 0 ? "یک" : "دو"}`; subtitle = "رقابت دونفره با موفقیت به پایان رسید."; }
    else if (current.mode === "boss" && win) { title = "استاد شکست خورد!"; subtitle = "پاداش ویژه و شخصیت تازه به دست آمد."; }
    else if (current.mode === "boss" && !win) { title = "جانها تمام شد"; subtitle = "دفعهٔ بعد با دقت بیشتر برگرد!"; }
    else if (win) { title = "پیروزی درخشان!"; subtitle = "واژهها به کمکت آمدند."; }
    else { title = "پایان رقابت"; subtitle = "تمرین، راه قهرمان شدن است."; }

    setResult({
      mode: current.mode,
      score: current.score,
      correct: current.correctCount,
      total: answered,
      coins: current.coins + bonusCoins,
      xp: current.xpGain + bonusXp,
      win,
      quit,
      title,
      subtitle,
      isBest,
      perfect,
      starCount,
      duoScores: current.mode === "duo" ? current.scores : undefined,
      newLevel: afterLevel > beforeLevel ? afterLevel : undefined,
      specialReward,
      topScores,
    });
    setGame({ ...current, paused: false, deadline: null });
    setTimeLeft(0);
    setBurstSeed(0);
    audio.play(win || quit ? "victory" : "defeat");
  }

  function advance() {
    const current = gameRef.current;
    if (!current || current.phase !== "feedback" || current.paused || resultRef.current) return;
    const planned = MODE_INFO[current.mode].length;
    const countDone = current.index + 1;
    if ((Number.isFinite(planned) && countDone >= planned) || (current.mode === "boss" && current.lives <= 0)) {
      finishGame(current);
      return;
    }
    let deck = current.deck;
    if (current.mode === "practice" && current.index + 1 >= deck.length) {
      deck = [...deck, ...extendDeck(deck, progressRef.current.seenIds)];
    }
    const nextIndex = current.index + 1;
    const timer = MODE_INFO[current.mode].timer;
    const nextPlayer: Player = current.mode === "duo" ? (current.player === 0 ? 1 : 0) : 0;
    const next: Game = {
      ...current,
      deck,
      index: nextIndex,
      phase: "answering",
      selected: null,
      correct: null,
      timedOut: false,
      player: nextPlayer,
      paused: false,
      deadline: timer > 0 ? Date.now() + timer * 1000 : null,
      remaining: timer,
      lastGain: 0,
    };
    lockRef.current = false;
    setGame(next);
    setTimeLeft(timer);
    setBurstSeed(0);
    setShake(false);
    audio.play("whoosh");
    if (deck[nextIndex]) speakQuestion(deck[nextIndex]);
    if (current.mode === "duo") showToast(`نوبت بازیکن ${nextPlayer === 0 ? "یک" : "دو"}`);
  }

  function togglePause() {
    const current = gameRef.current;
    if (!current || resultRef.current || screenRef.current !== "quiz") return;
    clearNarration();
    if (current.paused) {
      const timer = MODE_INFO[current.mode].timer;
      setGame({
        ...current,
        paused: false,
        deadline: current.phase === "answering" && timer > 0 ? Date.now() + current.remaining * 1000 : null,
      });
      setTimeLeft(current.remaining);
      audio.play("click");
    } else {
      const remaining = current.deadline ? Math.max(0.2, (current.deadline - Date.now()) / 1000) : 0;
      setGame({ ...current, paused: true, deadline: null, remaining });
      setTimeLeft(remaining);
      audio.play("click");
    }
  }

  function restartGame() {
    const mode = gameRef.current?.mode ?? "competition";
    startGame(mode);
  }

  function buyOrEquip(kind: "char" | "theme", id: string) {
    const list = kind === "char" ? CHARACTERS : THEMES;
    const item = list.find((x) => x.id === id);
    if (!item) return;
    const owned = kind === "char" ? progressRef.current.unlockedChars : progressRef.current.unlockedThemes;
    audio.unlock();
    if (!owned.includes(id)) {
      if (progressRef.current.coins < item.cost) {
        showToast(`به ${fa(item.cost - progressRef.current.coins)} سکهٔ دیگر نیاز داری`);
        audio.play("wrong");
        return;
      }
      setProgress((p) => ({
        ...p,
        coins: p.coins - item.cost,
        [kind === "char" ? "unlockedChars" : "unlockedThemes"]: [...(kind === "char" ? p.unlockedChars : p.unlockedThemes), id],
        [kind]: id,
      }));
      showToast(`«${item.name}» آزاد و انتخاب شد!`);
      audio.play("coin");
    } else {
      setProgress((p) => ({ ...p, [kind]: id }));
      showToast(`«${item.name}» انتخاب شد`);
      audio.play("click");
    }
  }

  async function handleInstall() {
    if (!installPrompt) { setInstallHelp(true); return; }
    await installPrompt.prompt();
    try { await installPrompt.userChoice; } catch { /* ignored */ }
    setInstallPrompt(null);
    showToast("اگر نصب کامل نشد، از منوی مرورگر «افزودن به صفحهٔ اصلی» را بزن");
  }

  function resetProgress() {
    localStorage.removeItem("persian-quest-grade7-v1");
    const fresh = loadProgress();
    setProgress(fresh);
    progressRef.current = fresh;
    setConfirmReset(false);
    setLeaderboardFilter("all");
    showToast("پیشرفت از نو آغاز شد");
    audio.play("whoosh");
  }

  useEffect(() => { saveProgress(progress); }, [progress]);
  useEffect(() => { audio.setSettings(progress.settings); }, [progress.settings]);
  useEffect(() => {
    const fresh = ACHIEVEMENTS.filter((a) => a.condition(progress) && !progress.achievements.includes(a.id));
    if (fresh.length) {
      setProgress((p) => ({
        ...p,
        achievements: [...p.achievements, ...fresh.map((a) => a.id)],
        coins: p.coins + fresh.length * 20,
        totalCoins: p.totalCoins + fresh.length * 20,
      }));
      showToast(`🏅 نشان «${fresh[0].title}» آزاد شد! +${fa(fresh.length * 20)} سکه`);
      audio.play("coin");
    }
  }, [progress]);
  useEffect(() => {
    const unlock = () => audio.unlock();
    window.addEventListener("pointerdown", unlock, { once: true });
    const sw = () => {
      if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
        navigator.serviceWorker.register("./sw.js").catch(() => {});
      }
    };
    sw();
    const installHandler = (e: Event) => { e.preventDefault(); setInstallPrompt(e as InstallEvent); };
    window.addEventListener("beforeinstallprompt", installHandler);
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("beforeinstallprompt", installHandler);
      if (toastTimer.current !== null) window.clearTimeout(toastTimer.current);
      if (shakeTimer.current !== null) window.clearTimeout(shakeTimer.current);
      clearNarration();
    };
  }, []);
  useEffect(() => {
    const current = game;
    if (!current || current.paused || current.phase !== "answering" || current.deadline === null || result) return;
    const deadline = current.deadline;
    let lastSecond = Math.ceil((deadline - Date.now()) / 1000);
    const id = window.setInterval(() => {
      const left = Math.max(0, (deadline - Date.now()) / 1000);
      setTimeLeft(left);
      const second = Math.ceil(left);
      if (second <= 5 && second > 0 && second !== lastSecond) { audio.play("tick"); lastSecond = second; }
      if (left <= 0) {
        window.clearInterval(id);
        actionsRef.current.answer(-1);
      }
    }, 80);
    return () => window.clearInterval(id);
  }, [game?.deadline, game?.paused, game?.phase, result]);
  useEffect(() => {
    if (!game || game.paused || game.phase !== "feedback" || result) return;
    const delay = game.mode === "practice" ? 5200 : 3400;
    const id = window.setTimeout(() => actionsRef.current.advance(), delay);
    return () => window.clearTimeout(id);
  }, [game?.index, game?.phase, game?.paused, result]);
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && /INPUT|TEXTAREA|SELECT/.test(target.tagName)) return;
      const key = e.key.toLowerCase();
      const digitIndex = ["1", "2", "3", "4", "۱", "۲", "۳", "۴", "a", "b", "c", "d"].indexOf(key);
      let handled = true;
      if (installHelp && (key === "escape" || key === "enter")) setInstallHelp(false);
      else if (resultRef.current) {
        if (key === "enter" || key === " " || key === "r") actionsRef.current.restart();
        else if (key === "h" || key === "escape") actionsRef.current.home();
        else handled = false;
      } else if (screenRef.current === "quiz" && gameRef.current) {
        if (digitIndex >= 0) actionsRef.current.answer(digitIndex % 4);
        else if (key === "enter" || key === " ") {
          if (gameRef.current.phase === "feedback") actionsRef.current.advance();
          else handled = false;
        } else if (key === "p" || key === "escape") actionsRef.current.pause();
        else if (key === "r") actionsRef.current.restart();
        else if (key === "h") actionsRef.current.home();
        else handled = false;
      } else if (screenRef.current === "home") {
        if (key === "enter" || key === " ") actionsRef.current.start("competition");
        else if (key === "l") { screenRef.current = "leaderboard"; setScreen("leaderboard"); }
        else handled = false;
      } else if (key === "escape" || key === "h") actionsRef.current.home();
      else handled = false;
      if (key === "m") { actionsRef.current.toggleSound(); handled = true; }
      else if (key === "r" && screenRef.current !== "quiz" && !resultRef.current) { handled = false; }
      if (handled) e.preventDefault();
      audio.unlock();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [installHelp]);

  actionsRef.current = {
    answer: answerQuestion,
    advance,
    start: startGame,
    restart: restartGame,
    home: goHome,
    pause: togglePause,
    toggleSound,
  };

  const level = levelForXp(progress.xp);
  const levelInfo = LEVELS[level.index];
  const themeClass = THEMES.find((t) => t.id === progress.theme)?.className ?? "";
  const question = game?.deck[game.index] ?? null;

  function HomeView() {
    return (
      <div className="fade-in min-h-full px-4 pb-8 pt-4">
        <div className="mb-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-[var(--gold)] text-xl shadow-lg">📜</div>
            <div>
              <p className="text-[.65rem] font-bold text-[var(--muted)]">پایهٔ هفتم • بازی آموزشی</p>
              <p className="text-sm font-black text-[var(--gold)]">سرزمین فارسی</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="chip chip-gold">🪙 {fa(progress.coins)}</div>
            <button className="btn btn-ghost btn-icon" onClick={toggleSound} aria-label={progress.settings.sound ? "خاموش کردن صدا" : "روشن کردن صدا"}>
              {progress.settings.sound ? "🔊" : "🔇"}
            </button>
          </div>
        </div>

        <div className="relative mb-4">
          <HeroScene char={progress.char} />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 px-4 pb-3 text-center">
            <h1 className="title-glow text-[1.55rem] leading-tight font-black text-white sm:text-[1.8rem]">ماجراجویی در سرزمین فارسی</h1>
            <p className="mt-1 text-[.72rem] font-bold text-[#ffe9b8]">واژهها را بشناس، شعرها را کشف کن و قهرمان شو</p>
          </div>
        </div>

        <div className="panel mb-4 p-3">
          <div className="flex items-center gap-3">
            <Mascot char={progress.char} className="h-14 w-14 shrink-0 text-[1.8rem]" />
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-sm font-black">{progress.name}</p>
                <span className="chip chip-teal">{levelInfo.icon} سطح {fa(level.level)} • {levelInfo.title}</span>
              </div>
              <div className="meter mt-2"><div className="meter-fill" style={{ width: `${level.progress}%` }} /></div>
              <p className="mt-1 text-[.68rem] text-[var(--muted)]">تجربه {fa(progress.xp)} • تا سطح بعد {fa(level.toNext)}</p>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <div className="soft-panel py-2"><p className="text-base font-black text-[var(--gold)]">{fa(progress.totalCorrect)}</p><p className="text-[.65rem] text-[var(--muted)]">پاسخ درست</p></div>
            <div className="soft-panel py-2"><p className="text-base font-black text-[var(--teal)]">{fa(progress.bestStreak)}</p><p className="text-[.65rem] text-[var(--muted)]">بهترین ترکیب</p></div>
            <div className="soft-panel py-2"><p className="text-base font-black text-[var(--rose)]">{fa(questionCount())}</p><p className="text-[.65rem] text-[var(--muted)]">پرسش بانک</p></div>
          </div>
        </div>

        <button className="btn btn-primary mb-3 w-full text-lg" onClick={() => startGame("competition")}>
          <span className="text-2xl">▶</span> شروع ماجراجویی <span className="chip chip-gold">رقابت ۲۰ پرسشی</span>
        </button>

        <div className="mb-3 grid grid-cols-2 gap-2.5">
          {(["practice", "boss", "duo", "daily"] as Mode[]).map((mode) => {
            const info = MODE_INFO[mode];
            return (
              <button key={mode} className="mode-card" style={{ "--tint": info.color } as CSSProperties} onClick={() => startGame(mode)}>
                <span className="mode-icon">{info.icon}</span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-black text-white">{info.title}</span>
                  <span className="mt-0.5 block text-[.66rem] leading-5 text-[var(--muted)]">{info.description}</span>
                  {mode === "daily" && progress.dailyDate === getDailySeed() && <span className="chip chip-teal mt-1 !py-0 !text-[.6rem]">امروز انجام شد</span>}
                </span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-4 gap-2">
          {[
            { icon: "🏅", label: "نشانها", to: "achievements" as Screen },
            { icon: "🛍️", label: "فروشگاه", to: "shop" as Screen },
            { icon: "📊", label: "رتبهها", to: "leaderboard" as Screen },
            { icon: "⚙️", label: "تنظیمات", to: "settings" as Screen },
          ].map((b) => (
            <button key={b.to} className="btn btn-ghost flex-col !gap-0.5 !px-1 !py-2 !text-[.7rem]" onClick={() => { audio.play("click"); setScreen(b.to); }}>
              <span className="text-xl">{b.icon}</span>{b.label}
            </button>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-center">
          <span className="chip">🎯 {fa(progress.games)} دور بازی</span>
          <span className="chip">🏅 {fa(progress.achievements.length)} نشان</span>
          <span className="chip">📴 کاملاً آفلاین</span>
        </div>
        <p className="mt-3 hidden text-center text-[.66rem] text-[var(--muted)] sm:block">
          کلیدهای <span className="kbd">۱</span> تا <span className="kbd">۴</span> برای پاسخ • <span className="kbd">Enter</span> ادامه • <span className="kbd">P</span> توقف • <span className="kbd">R</span> شروع دوباره • <span className="kbd">M</span> صدا
        </p>
      </div>
    );
  }

  function QuizView() {
    if (!game || !question) return null;
    const info = MODE_INFO[game.mode];
    const timer = info.timer;
    const planned = Number.isFinite(info.length) ? info.length : 20;
    const progressPercent = Math.min(100, ((game.index + (game.phase === "feedback" ? 1 : 0)) / planned) * 100);
    const ringProgress = timer > 0 ? Math.min(100, (timeLeft / timer) * 100) : 100;
    const danger = timer > 0 && timeLeft <= 5;
    return (
      <div className="fade-in min-h-full px-4 pb-7 pt-4">
        <div className="mb-3 flex items-center justify-between gap-2">
          <button className="btn btn-ghost btn-icon" onClick={togglePause} aria-label="توقف">⏸</button>
          <div className="text-center">
            <p className="text-sm font-black text-[var(--gold)]">{info.icon} {info.title}</p>
            <p className="text-[.66rem] text-[var(--muted)]">پرسش {fa(game.index + 1)}{Number.isFinite(info.length) ? ` از ${fa(info.length)}` : ""}</p>
          </div>
          <button className="btn btn-ghost btn-icon" onClick={toggleSound} aria-label="صدا">{progress.settings.sound ? "🔊" : "🔇"}</button>
        </div>

        <div className="panel mb-3 flex items-center justify-between gap-2 p-2.5">
          {timer > 0 ? (
            <div className={`timer-ring ${danger ? "timer-danger" : ""}`} style={{ "--progress": `${ringProgress}%` } as CSSProperties}>
              <span className="timer-num">{fa(Math.ceil(timeLeft))}</span>
            </div>
          ) : <div className="chip chip-teal px-3 py-2">⏳ زمان آزاد</div>}
          <div className="flex-1">
            <div className="mb-1.5 flex flex-wrap items-center justify-center gap-1">
              <span className="chip chip-gold">⭐ {fa(game.score)}</span>
              <span className="chip">🔥 {fa(game.streak)}</span>
              {game.mode === "boss" && <span className="chip chip-rose">❤️ {fa(game.lives)}</span>}
              {game.mode === "duo" && <span className="chip chip-teal">{game.player === 0 ? "بازیکن یک" : "بازیکن دو"}</span>}
            </div>
            <div className="meter"><div className="meter-fill" style={{ width: `${progressPercent}%` }} /></div>
          </div>
        </div>

        {game.mode === "duo" && (
          <div className="soft-panel mb-3 flex items-center justify-around p-2 text-xs font-black">
            <span className={game.player === 0 ? "text-[var(--gold)]" : "text-[var(--muted)]"}>بازیکن یک: {fa(game.scores[0])}</span>
            <span className="text-[var(--muted)]">⚔️</span>
            <span className={game.player === 1 ? "text-[var(--gold)]" : "text-[var(--muted)]"}>بازیکن دو: {fa(game.scores[1])}</span>
          </div>
        )}

        <div className="panel question-card mb-3 p-4">
          <div className="mb-3 flex flex-wrap items-center gap-1.5">
            <span className="chip chip-gold">{question.topic}</span>
            <span className="chip">{DIFFICULTY_LABELS[question.difficulty]}</span>
            <span className="chip">بخش {fa(question.lesson)}</span>
          </div>
          <p className="text-[.98rem] leading-8 font-extrabold sm:text-[1.05rem]">{question.text}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button className="btn btn-ghost btn-sm" onClick={() => { audio.unlock(); audio.speakQuestion(question.text, true); }}>🔊 شنیدن پرسش</button>
            <button className="btn btn-ghost btn-sm" onClick={() => { audio.unlock(); audio.speakOptions(question.options, OPTION_WORDS); }}>🎧 شنیدن گزینهها</button>
          </div>
        </div>

        <div className="space-y-2.5">
          {question.options.map((option, i) => {
            const revealed = game.phase === "feedback";
            const isCorrect = revealed && i === question.answer;
            const isWrong = revealed && game.selected === i && !game.correct;
            const dim = revealed && !isCorrect && !isWrong;
            return (
              <button
                key={i}
                className={`quiz-option ${isCorrect ? "is-correct" : ""} ${isWrong ? "is-wrong" : ""} ${dim ? "is-dim" : ""}`}
                disabled={revealed || game.paused}
                onClick={() => answerQuestion(i)}
              >
                <span className="option-key">{OPTION_KEYS[i]}</span>
                <span className="flex-1">{option}</span>
                {isCorrect && <span className="text-xl">✓</span>}
                {isWrong && <span className="text-xl">✕</span>}
              </button>
            );
          })}
        </div>

        {game.phase === "feedback" && (
          <div className={`feedback-panel mt-3 ${!game.correct ? "is-bad" : ""}`}>
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-black">
                {game.correct ? "🎉 آفرین! پاسخ درست" : game.timedOut ? "⏰ زمان تمام شد" : "💪 پاسخ نادرست"}
              </p>
              {game.correct && <span className="chip chip-gold">+{fa(game.lastGain)} امتیاز</span>}
            </div>
            <p className="mt-2 text-[.82rem] leading-6"><b className="text-[var(--teal)]">پاسخ درست:</b> {question.options[question.answer]}</p>
            <p className="mt-1 text-[.8rem] leading-6 text-[var(--muted)]"><b className="text-[var(--gold)]">چرا؟</b> {question.explanation}</p>
            <button className="btn btn-primary mt-3 w-full" onClick={advance}>
              {game.mode === "boss" && game.lives <= 0 ? "پایان چالش" : "پرسش بعدی"} <span className="kbd">Enter</span>
            </button>
          </div>
        )}

        <div className="mt-3 flex items-center justify-center gap-2 text-[.66rem] text-[var(--muted)]">
          <span className="kbd">۱</span><span className="kbd">۲</span><span className="kbd">۳</span><span className="kbd">۴</span>
          <span>پاسخ •</span><span className="kbd">P</span><span>توقف •</span><span className="kbd">R</span><span>دوباره</span>
        </div>
        {game.phase === "feedback" && game.correct && (
          <div className="pointer-events-none absolute inset-x-0 top-1/2 z-30 text-center">
            <span className="float-up inline-block text-2xl font-black text-[var(--gold)]" style={{ textShadow: "0 3px 12px #000" }}>+{fa(game.lastGain)} ✨</span>
          </div>
        )}
      </div>
    );
  }

  function AchievementsView() {
    return (
      <div className="fade-in min-h-full px-4 pb-8 pt-4">
        <SubHeader title="نشانها و افتخارات" subtitle={`${fa(progress.achievements.length)} نشان از ${fa(ACHIEVEMENTS.length)} آزاد شده`} onBack={goHome} />
        <div className="panel mb-4 flex items-center gap-3 p-4">
          <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[#ffe9a8] to-[#f0a736] text-3xl shadow-lg">🏆</div>
          <div className="flex-1">
            <p className="text-sm font-black">{levelInfo.icon} {levelInfo.title}</p>
            <p className="text-[.72rem] text-[var(--muted)]">سطح {fa(level.level)} از ۱۰ • تجربه {fa(progress.xp)}</p>
            <div className="meter mt-2"><div className="meter-fill" style={{ width: `${level.progress}%` }} /></div>
          </div>
        </div>
        <div className="mb-4 grid grid-cols-3 gap-2">
          {[
            { icon: "🐉", label: "پیروزی بر استاد", value: progress.bossWins },
            { icon: "💎", label: "دورهای بینقص", value: progress.perfectRounds },
            { icon: "📅", label: "چالشهای روزانه", value: progress.dailyCount },
          ].map((t) => (
            <div key={t.label} className="soft-panel p-2 text-center">
              <p className="text-2xl">{t.icon}</p><p className="text-lg font-black text-[var(--gold)]">{fa(t.value)}</p><p className="text-[.62rem] text-[var(--muted)]">{t.label}</p>
            </div>
          ))}
        </div>
        <div className="space-y-2">
          {ACHIEVEMENTS.map((a) => {
            const unlocked = progress.achievements.includes(a.id);
            return (
              <div key={a.id} className={`badge-tile ${unlocked ? "" : "locked"}`}>
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/10 text-2xl">{unlocked ? a.icon : "🔒"}</div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-black">{a.title}</p>
                  <p className="text-[.69rem] text-[var(--muted)]">{a.description}</p>
                </div>
                {unlocked && <span className="chip chip-gold">آزاد ✓</span>}
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  function ShopView() {
    return (
      <div className="fade-in min-h-full px-4 pb-8 pt-4">
        <SubHeader title="فروشگاه ماجراجو" subtitle="با سکهها شخصیت و پسزمینه آزاد کن" onBack={goHome} />
        <div className="panel mb-4 flex items-center justify-between p-3">
          <span className="text-sm font-black">🪙 سکههای تو</span>
          <span className="chip chip-gold text-base">{fa(progress.coins)}</span>
        </div>
        <h3 className="mb-2 text-sm font-black text-[var(--teal)]">شخصیتها</h3>
        <div className="mb-5 grid grid-cols-2 gap-2">
          {CHARACTERS.map((c) => {
            const owned = progress.unlockedChars.includes(c.id);
            const active = progress.char === c.id;
            return (
              <button key={c.id} className="mode-card flex-col !items-stretch !gap-2 text-center" onClick={() => buyOrEquip("char", c.id)}>
                <span className="text-3xl">{c.icon}</span>
                <span className="text-xs font-black">{c.name}</span>
                <span className={`chip mx-auto ${active ? "chip-teal" : owned ? "chip-gold" : ""}`}>{active ? "در حال استفاده" : owned ? "انتخاب" : `🪙 ${fa(c.cost)}`}</span>
              </button>
            );
          })}
        </div>
        <h3 className="mb-2 text-sm font-black text-[var(--rose)]">پسزمینهها</h3>
        <div className="grid grid-cols-2 gap-2">
          {THEMES.map((t) => {
            const owned = progress.unlockedThemes.includes(t.id);
            const active = progress.theme === t.id;
            return (
              <button key={t.id} className="mode-card flex-col !items-stretch !gap-2 text-center" onClick={() => buyOrEquip("theme", t.id)}>
                <span className="text-3xl">{t.icon}</span>
                <span className="text-xs font-black">{t.name}</span>
                <span className={`chip mx-auto ${active ? "chip-teal" : owned ? "chip-gold" : ""}`}>{active ? "در حال استفاده" : owned ? "انتخاب" : `🪙 ${fa(t.cost)}`}</span>
              </button>
            );
          })}
        </div>
        <p className="mt-4 text-center text-[.7rem] leading-6 text-[var(--muted)]">هر پاسخ درست سکه میدهد؛ پاسخ سریع و ترکیبهای پیاپی پاداش بیشتری دارند.</p>
      </div>
    );
  }

  function SettingsView() {
    return (
      <div className="fade-in min-h-full px-4 pb-8 pt-4">
        <SubHeader title="تنظیمات" subtitle="بازی را به دلخواه خود تنظیم کن" onBack={goHome} />
        <div className="panel mb-4 p-3">
          <p className="mb-2 text-xs font-black text-[var(--gold)]">نام بازیکن</p>
          <input className="text-input" value={progress.name} maxLength={24} onChange={(e) => setProgress((p) => ({ ...p, name: e.target.value }))} placeholder="نام خود را بنویس" />
        </div>
        <div className="space-y-2">
          {[
            { key: "sound" as const, icon: "🔊", title: "صدا و جلوهها", desc: "پاسخ، شمارش و پیروزی" },
            { key: "music" as const, icon: "🎵", title: "موسیقی پسزمینه", desc: "ملودی ملایم و کمحجم" },
            { key: "narration" as const, icon: "🗣️", title: "خوانش پرسشها", desc: "گفتار فارسی دستگاه، در صورت پشتیبانی" },
            { key: "reduceMotion" as const, icon: "⚡", title: "کاهش انیمیشن", desc: "حرکتهای کمتر و مصرف باتری پایینتر" },
          ].map((row) => (
            <div key={row.key} className="setting-row">
              <div className="flex items-center gap-2">
                <span className="text-xl">{row.icon}</span>
                <div><p className="text-sm font-black">{row.title}</p><p className="text-[.66rem] text-[var(--muted)]">{row.desc}</p></div>
              </div>
              <Toggle on={Boolean(progress.settings[row.key])} onChange={() => { audio.unlock(); setSetting(row.key, !progress.settings[row.key] as never); }} label={row.title} />
            </div>
          ))}
          <div className="setting-row flex-col !items-stretch">
            <div className="flex items-center justify-between"><p className="text-sm font-black">سرعت گفتار فارسی</p><span className="chip chip-gold">{fa(progress.settings.voiceRate.toFixed(1))}×</span></div>
            <input type="range" min={0.7} max={1.2} step={0.1} value={progress.settings.voiceRate} className="w-full accent-[var(--gold)]" onChange={(e) => setSetting("voiceRate", Number(e.target.value))} />
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button className="btn btn-teal" onClick={handleInstall}>📲 نصب آفلاین</button>
          <button className="btn btn-violet" onClick={() => setScreen("about")}>ℹ️ دربارهٔ بازی</button>
        </div>
        <div className="mt-4 rounded-2xl border border-[var(--line)] bg-white/5 p-3">
          {!confirmReset ? (
            <button className="btn btn-ghost w-full !text-[.8rem]" onClick={() => setConfirmReset(true)}>پاک کردن پیشرفت و امتیازها</button>
          ) : (
            <div className="text-center">
              <p className="mb-2 text-xs">همهٔ سکهها، نشانها و رتبهها پاک میشوند. مطمئنی؟</p>
              <div className="flex gap-2"><button className="btn btn-rose flex-1" onClick={resetProgress}>بله، پاک کن</button><button className="btn btn-ghost flex-1" onClick={() => setConfirmReset(false)}>انصراف</button></div>
            </div>
          )}
        </div>
      </div>
    );
  }

  function AboutView() {
    return (
      <div className="fade-in min-h-full px-4 pb-8 pt-4">
        <SubHeader title="دربارهٔ بازی" subtitle="ماجراجویی در سرزمین فارسی • پایهٔ هفتم" onBack={() => setScreen("settings")} />
        <div className="panel space-y-3 p-4 text-[.82rem] leading-7">
          <p>این بازی یک ماجراجویی آموزشی برای تمرین <b>درک مطلب، واژگان، املا، دستور زبان، آرایهها، شعر و ضربالمثلها</b> است. بانک آن بیش از {fa(questionCount())} پرسش یکتا با پاسخ و توضیح دارد.</p>
          <p>پرسشها همسو با مهارتهای رایج کتاب فارسی پایهٔ هفتم تهیه شدهاند و <b>ادعای بازنویسی رسمی متن کتاب یا انتساب تازهای به شاعران ندارند</b>؛ متنهای درک مطلب و تمرینها نوشتهٔ خود بازیاند.</p>
          <p>گفتار فارسی از صدای نصبشده روی دستگاه استفاده میکند. اگر مرورگر صدای فارسی نداشته باشد، بازی همچنان کاملاً قابل بازی است.</p>
          <p>پیشرفت، سکهها، نشانها و جدول امتیازها فقط روی همین دستگاه و بدون اینترنت ذخیره میشوند. هیچ تبلیغ و پرداختی در بازی وجود ندارد.</p>
          <div className="soft-panel p-3 text-[.75rem]">
            <p className="font-black text-[var(--gold)]">نسخه و نصب</p>
            <p>این محصول یک <b>برنامهٔ وب نصبشدنی و آفلاین</b> است که روی اندروید ۸ و بالاتر از طریق مرورگر کروم نصب میشود. محیط ساخت وب، فایل نصبی APK تولید نمیکند؛ برای دریافت APK باید همین بستهٔ وب را با ابزار بستهبندی بومی اندروید کپسوله کرد.</p>
          </div>
        </div>
        <button className="btn btn-primary mt-4 w-full" onClick={goHome}>بازگشت به خانه</button>
      </div>
    );
  }

  function LeaderboardView() {
    const filtered = progress.scores
      .filter((s) => leaderboardFilter === "all" || s.mode === leaderboardFilter)
      .sort((a, b) => b.score - a.score)
      .slice(0, 12);
    return (
      <div className="fade-in min-h-full px-4 pb-8 pt-4">
        <SubHeader title="جدول قهرمانان" subtitle="امتیازهای ذخیرهشده روی این دستگاه" onBack={goHome} />
        <div className="mb-3 flex flex-wrap gap-1.5">
          <button className={`chip ${leaderboardFilter === "all" ? "chip-gold" : ""}`} onClick={() => setLeaderboardFilter("all")}>همه</button>
          {(Object.keys(MODE_INFO) as Mode[]).map((m) => (
            <button key={m} className={`chip ${leaderboardFilter === m ? "chip-gold" : ""}`} onClick={() => setLeaderboardFilter(m)}>{MODE_INFO[m].short}</button>
          ))}
        </div>
        {filtered.length === 0 ? (
          <div className="panel p-8 text-center">
            <p className="mb-2 text-5xl">🏆</p><p className="text-sm font-black">هنوز امتیازی ثبت نشده</p>
            <p className="mt-1 text-xs text-[var(--muted)]">یک رقابت آغاز کن و نامت را در جدول بگذار.</p>
            <button className="btn btn-primary mt-4" onClick={() => startGame("competition")}>شروع رقابت</button>
          </div>
        ) : (
          <div className="space-y-1.5">
            <div className="table-row !bg-transparent !text-[.68rem] font-black text-[var(--muted)]"><span>#</span><span>بازیکن</span><span>حالت</span><span>امتیاز</span></div>
            {filtered.map((s, i) => (
              <div key={s.id} className={`table-row ${i === 0 ? "current" : ""}`}>
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-white/10 font-black">{fa(i + 1)}</span>
                <span className="min-w-0 truncate"><b>{s.name}</b><br /><span className="text-[.65rem] text-[var(--muted)]">{s.date} • {fa(s.correct)}/{fa(s.total)} درست</span></span>
                <span className="text-[.68rem] text-[var(--muted)]">{MODE_INFO[s.mode]?.short ?? s.mode}</span>
                <span className="font-black text-[var(--gold)]">{fa(s.score)}</span>
              </div>
            ))}
          </div>
        )}
        <p className="mt-4 text-center text-[.7rem] text-[var(--muted)]">جدول محلی است و به اینترنت نیاز ندارد.</p>
      </div>
    );
  }

  function PauseOverlay() {
    return (
      <div className="overlay">
        <div className="modal text-center">
          <div className="mb-2 text-5xl">⏸️</div>
          <h2 className="text-2xl font-black text-[var(--gold)]">توقف بازی</h2>
          <p className="mt-1 text-xs text-[var(--muted)]">نفسی تازه کن؛ زمان هم متوقف شده است.</p>
          <div className="mt-5 space-y-2">
            <button className="btn btn-primary w-full" onClick={togglePause}>ادامهٔ ماجراجویی <span className="kbd">P</span></button>
            <button className="btn btn-violet w-full" onClick={restartGame}>شروع دوباره <span className="kbd">R</span></button>
            <button className="btn btn-ghost w-full" onClick={() => { if (gameRef.current) finishGame(gameRef.current, true); }}>خروج و ذخیرهٔ نتیجه</button>
          </div>
        </div>
      </div>
    );
  }

  function ResultOverlay() {
    if (!result) return null;
    const accuracy = result.total ? Math.round((result.correct / result.total) * 100) : 0;
    return (
      <div className="overlay">
        {result.win && <Confetti />}
        <div className="modal pop-in text-center">
          <div className={`mx-auto mb-2 grid h-20 w-20 place-items-center rounded-full text-4xl ${result.win ? "bg-[var(--gold)]" : "bg-white/10"}`}>
            {result.win ? "🏆" : result.quit ? "📖" : "💪"}
          </div>
          <p className="text-[.72rem] font-black text-[var(--teal)]">{MODE_INFO[result.mode].icon} {MODE_INFO[result.mode].title}</p>
          <h2 className="mt-1 text-2xl font-black text-[var(--gold)]">{result.title}</h2>
          <p className="mt-1 text-xs text-[var(--muted)]">{result.subtitle}</p>
          <div className="my-3"><Stars count={result.starCount} /></div>
          <div className="panel !rounded-2xl p-3">
            <p className="text-[.68rem] text-[var(--muted)]">امتیاز نهایی</p>
            <p className="text-4xl font-black text-[var(--gold)]">{fa(result.score)}</p>
            {result.isBest && <span className="chip chip-rose mt-1">✨ رکورد تازه</span>}
            <div className="mt-3 grid grid-cols-4 gap-1.5 text-center">
              <div className="soft-panel py-2"><p className="text-sm font-black">{fa(result.correct)}/{fa(result.total)}</p><p className="text-[.6rem] text-[var(--muted)]">درست</p></div>
              <div className="soft-panel py-2"><p className="text-sm font-black">{fa(accuracy)}٪</p><p className="text-[.6rem] text-[var(--muted)]">دقت</p></div>
              <div className="soft-panel py-2"><p className="text-sm font-black text-[var(--gold)]">+{fa(result.coins)}</p><p className="text-[.6rem] text-[var(--muted)]">سکه</p></div>
              <div className="soft-panel py-2"><p className="text-sm font-black text-[var(--teal)]">+{fa(result.xp)}</p><p className="text-[.6rem] text-[var(--muted)]">تجربه</p></div>
            </div>
            {result.duoScores && <p className="mt-2 text-xs font-black">بازیکن یک {fa(result.duoScores[0])} ⚔️ بازیکن دو {fa(result.duoScores[1])}</p>}
            {result.perfect && <p className="mt-2 text-xs font-black text-[var(--teal)]">💎 دور بینقص! نشان ویژه آزاد شد.</p>}
            {result.newLevel && <p className="mt-2 text-xs font-black text-[var(--gold)]">🎉 به سطح {fa(result.newLevel)} رسیدی!</p>}
            {result.specialReward && <p className="mt-2 text-xs font-black text-[var(--rose)]">🎁 {result.specialReward}</p>}
          </div>
          <h3 className="mb-1.5 mt-4 text-right text-xs font-black text-[var(--gold)]">جدول برترینها</h3>
          <div className="max-h-36 space-y-1 overflow-y-auto text-right">
            {result.topScores.slice(0, 5).map((s, i) => (
              <div key={s.id} className="table-row !text-[.7rem]"><span>{fa(i + 1)}</span><span className="truncate">{s.name}</span><span className="text-[.62rem] text-[var(--muted)]">{MODE_INFO[s.mode]?.short}</span><span className="font-black text-[var(--gold)]">{fa(s.score)}</span></div>
            ))}
            {result.topScores.length === 0 && <p className="py-2 text-center text-[.72rem] text-[var(--muted)]">امتیازی ثبت نشده است.</p>}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <button className="btn btn-primary" onClick={restartGame}>🔁 دوباره <span className="kbd">R</span></button>
            <button className="btn btn-ghost" onClick={goHome}>🏠 خانه</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`app-frame ${themeClass} ${progress.settings.reduceMotion ? "reduce-motion" : ""} ${shake ? "shake" : ""}`}>
      <div className="pattern" />
      <div className="float-orb orb-1" /><div className="float-orb orb-2" /><div className="float-orb orb-3" />
      <div className="app-scroll">
        {screen === "home" && HomeView()}
        {screen === "quiz" && QuizView()}
        {screen === "achievements" && AchievementsView()}
        {screen === "shop" && ShopView()}
        {screen === "settings" && SettingsView()}
        {screen === "about" && AboutView()}
        {screen === "leaderboard" && LeaderboardView()}
      </div>
      {burstSeed > 0 && game?.phase === "feedback" && !result && <Particles seed={burstSeed} />}
      {toast && <div className="toast">{toast}</div>}
      {screen === "quiz" && game?.paused && !result && PauseOverlay()}
      {screen === "quiz" && result && ResultOverlay()}
      {installHelp && (
        <div className="overlay">
          <div className="modal text-center">
            <p className="text-4xl">📲</p>
            <h2 className="mt-2 text-xl font-black text-[var(--gold)]">نصب روی اندروید</h2>
            <p className="mt-2 text-xs leading-7 text-[var(--muted)]">در مرورگر کروم، منوی سه نقطه را باز کن و «افزودن به صفحهٔ اصلی» یا «نصب برنامه» را انتخاب کن. پس از نخستین اجرا، بازی بدون اینترنت هم کار میکند.</p>
            <button className="btn btn-primary mt-4 w-full" onClick={() => setInstallHelp(false)}>فهمیدم</button>
          </div>
        </div>
      )}
    </div>
  );
}
