import type { CSSProperties } from "react";
import { CHARACTERS } from "../lib/game";

export function HeroScene({ char }: { char: string }) {
  const avatar = CHARACTERS.find((c) => c.id === char)?.icon ?? "🧭";
  return (
    <div className="hero-scene" aria-hidden="true">
      <svg viewBox="0 0 500 220" width="100%" height="100%" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#3552a0" />
            <stop offset="0.55" stopColor="#221f5e" />
            <stop offset="1" stopColor="#102a4e" />
          </linearGradient>
          <radialGradient id="sunGlow">
            <stop offset="0" stopColor="#ffe9a8" />
            <stop offset="0.55" stopColor="#ffd166" />
            <stop offset="1" stopColor="#ff9f4b" stopOpacity="0.15" />
          </radialGradient>
          <linearGradient id="dome" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#78e6d6" />
            <stop offset="1" stopColor="#218d9c" />
          </linearGradient>
          <linearGradient id="page" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#fff7df" />
            <stop offset="1" stopColor="#ffd98a" />
          </linearGradient>
          <linearGradient id="hill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#1c6c71" />
            <stop offset="1" stopColor="#0a344c" />
          </linearGradient>
        </defs>
        <rect width="500" height="220" fill="url(#sky)" />
        <circle className="hero-sun" cx="250" cy="53" r="48" fill="url(#sunGlow)" opacity="0.9" />
        {[[62,38],[105,75],[390,40],[430,78],[355,22],[150,28]].map(([x,y],i)=>(
          <circle key={i} className="hero-star" cx={x} cy={y} r={i%2?2:3} fill="#fff3c4" style={{animationDelay:`${i*0.35}s`}} />
        ))}
        <g className="hero-bird" fill="none" stroke="#ffe3a6" strokeWidth="2" strokeLinecap="round">
          <path d="M0 70 q8 -8 16 0 q8 -8 16 0" />
          <path d="M42 60 q6 -6 12 0 q6 -6 12 0" />
        </g>
        <path d="M0 165 Q80 120 160 162 Q250 110 340 158 Q420 120 500 160 L500 220 L0 220 Z" fill="#16415f" opacity=".8" />
        <path d="M0 185 Q90 153 180 184 Q270 148 360 182 Q440 160 500 185 L500 220 L0 220 Z" fill="url(#hill)" />
        {/* بنایی با گنبد فیروزهای */}
        <g transform="translate(52,80)">
          <rect x="13" y="64" width="74" height="65" rx="5" fill="#e7b879" />
          <rect x="22" y="77" width="20" height="38" rx="9" fill="#35477d" />
          <rect x="58" y="77" width="20" height="38" rx="9" fill="#35477d" />
          <path d="M5 64 Q50 4 95 64 Z" fill="url(#dome)" />
          <path d="M47 21 L53 7 L59 21 Z" fill="#ffd166" />
          <path d="M13 64 h74" stroke="#fff1c5" strokeWidth="3" />
          <path d="M28 40 h44 M22 52 h56" stroke="#b8f4e9" strokeWidth="2" opacity=".7" />
        </g>
        {/* سروهای ایرانی */}
        {[[414,92,1],[452,104,.78],[28,112,.7]].map(([x,y,s],i)=>(
          <g key={i} transform={`translate(${x} ${y}) scale(${s})`}>
            <rect x="-3" y="55" width="6" height="28" fill="#6d4a35" />
            <path d="M0 0 C-17 22 -17 53 0 72 C17 53 17 22 0 0 Z" fill={i===0?"#1f9d81":"#13766e"} />
            <path d="M0 12 C-9 27 -9 48 0 64" fill="none" stroke="#8be0b0" strokeWidth="2" opacity=".55" />
          </g>
        ))}
        {/* کتاب درخشان */}
        <g className="hero-book" transform="translate(250,144)">
          <ellipse cx="0" cy="48" rx="100" ry="12" fill="#061d34" opacity=".5" />
          <path d="M-96 -24 Q-50 -40 -4 -24 L-4 35 Q-50 20 -96 35 Z" fill="url(#page)" stroke="#8b5a26" strokeWidth="3" strokeLinejoin="round" />
          <path d="M96 -24 Q50 -40 4 -24 L4 35 Q50 20 96 35 Z" fill="url(#page)" stroke="#8b5a26" strokeWidth="3" strokeLinejoin="round" />
          <path d="M0 -24 L0 36" stroke="#8b5a26" strokeWidth="5" />
          <path d="M-78 -12 h52 M-78 0 h52 M-78 12 h40 M22 -12 h52 M22 0 h52 M22 12 h40" stroke="#aa7a48" strokeWidth="2.5" strokeLinecap="round" opacity=".7" />
          <circle cx="0" cy="-47" r="7" fill="#ffe9a8" />
          <path d="M0 -66 v8 M0 -39 v8 M-19 -47 h8 M11 -47 h8" stroke="#ffe9a8" strokeWidth="3" strokeLinecap="round" />
        </g>
        {/* نقش مینیاتوری و شخصیت */}
        <g transform="translate(250,39)">
          <circle cx="0" cy="0" r="25" fill="#ffd166" opacity=".16" />
          <circle cx="0" cy="0" r="18" fill="#fff0c0" />
          <circle cx="0" cy="0" r="15" fill="#ffbd7a" />
          <text x="0" y="7" textAnchor="middle" fontSize="20">{avatar}</text>
        </g>
        <g fill="#ffd166" opacity=".65">
          {Array.from({length:12}).map((_,i)=>(
            <path key={i} d={`M${18+i*40} 207 l5 5 -5 5 -5 -5 Z`} />
          ))}
        </g>
      </svg>
    </div>
  );
}

export function Mascot({ char, className = "" }: { char: string; className?: string }) {
  const avatar = CHARACTERS.find((c) => c.id === char)?.icon ?? "🧭";
  return <div className={`avatar ${className}`} aria-hidden="true">{avatar}</div>;
}

const PARTICLE_COLORS = ["#ffd166", "#35d6c1", "#ff6d9e", "#9d7bff", "#ffffff"];

export function Particles({ seed }: { seed: number }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-20 overflow-hidden">
      {Array.from({ length: 22 }).map((_, i) => {
        const angle = (i / 22) * Math.PI * 2 + seed * 0.17;
        const distance = 70 + ((i * 37 + seed * 13) % 120);
        const style = {
          "--x": `${45 + ((i * 17 + seed) % 12)}%`,
          "--dx": `${Math.cos(angle) * distance}px`,
          "--dy": `${Math.sin(angle) * distance - 25}px`,
          "--rot": `${(i * 83 + seed * 31) % 720}deg`,
          "--delay": `${(i % 5) * 0.025}s`,
          "--color": PARTICLE_COLORS[i % PARTICLE_COLORS.length],
        } as CSSProperties;
        return <span key={i} className="particle" style={style} />;
      })}
    </div>
  );
}

export function Confetti({ count = 28 }: { count?: number }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-40 overflow-hidden">
      {Array.from({ length: count }).map((_, i) => {
        const style = {
          "--x": `${(i * 37) % 100}%`,
          "--color": PARTICLE_COLORS[i % PARTICLE_COLORS.length],
          "--delay": `${(i % 10) * -0.37}s`,
          "--dur": `${2.6 + (i % 5) * 0.45}s`,
        } as CSSProperties;
        return <span key={i} className="confetti-piece" style={style} />;
      })}
    </div>
  );
}

export function Stars({ count = 3 }: { count?: number }) {
  return <span className="tracking-widest text-[var(--gold)]" aria-label={`${count} ستاره`}>{"★".repeat(count)}{"☆".repeat(Math.max(0, 3 - count))}</span>;
}
